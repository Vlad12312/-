<div class="user-line-bg">
<div class="user-line">

</div>
</div>

<div class="line">
</div>
<div class="all-content">
<div class="intro-content">




<div class="fon">
<div style="float:left; width:90px; margin:2px 0px 0px 27px;"><a href="/?menu=admin4ik&sel=news"><img src="/img/btns/1.png"></a></div>
<div style="float:left; width:90px; margin:-2px 0px 0px 12px;"><a href="/?menu=admin4ik&sel=config"><img src="/img/btns/1.png"></a></div>
<div style="float:left; width:90px; margin:-6px 0px 0px 12px;"><a href="/?menu=admin4ik&sel=multi"><img src="/img/btns/1.png"></a></div>
<div style="float:left; width:90px; margin:-10px 0px 0px 12px;"><a href="/?menu=admin4ik&sel=sender"><img src="/img/btns/1.png"></a></div>
<div style="float:left; width:90px; margin:-12px 0px 0px 12px;"><a href="/?menu=admin4ik&sel=users"><img src="/img/btns/1.png"></a></div>
<div style="float:left; width:90px; margin:-10px 0px 0px 12px;"><a href="/?menu=admin4ik&sel=stats"><img src="/img/btns/1.png"></a></div>
</div>

<div class="user-content-fon">
<div class="clr"></div>
<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="99%">

<tr height='25' valign=top align=center>
<td align="center" class="m-tb"><b>ID</b></td>

<td align="center" class="m-tb"><b>������������</b></td>

<td align="center" class="m-tb"><b>IP</b></td>

<td align="center" class="m-tb"><b>��������</b></td>

<td align="center" class="m-tb"><b>��� ���������� IP</b></td>

<td align="center" class="m-tb"><b>��������</b></td>
</tr>


<?
if(isset($_POST["banned"])){

$db->Query("UPDATE db_users_a SET banned = '1' WHERE id = '".intval($_POST["banned"])."'");

echo "<center><b>������������ ".($_POST["banned"] > 0 ? "�������" : "��������")."</b></center><BR />";

}
else
if(isset($_POST["banneds"])){

$db->Query("SELECT ip FROM db_users_a WHERE id = '".intval($_POST["banneds"])."'");

$ip=$db->FetchArray();
	$ip=$ip['ip'];
	$db->Query("UPDATE db_users_a SET banned = '1' WHERE ip = '$ip' ");
echo "<center><b>������������ � ����� ip ".($_POST["banneds"] > 0 ? "��������" : "���������")."</b></center><BR />";

}
else
if(isset($_POST["hide"])){

$db->Query("UPDATE db_users_a SET hide = '1' WHERE id = '".intval($_POST["hide"])."' ");

echo "<center><b>������������ �����</b></center><BR />";

}

$db->Query("SELECT *, INET_NTOA(db_users_a.ip) uip FROM db_users_a WHERE ip IN (SELECT ip FROM db_users_a GROUP BY ip HAVING COUNT(*) > 1) AND banned = 0 AND hide = 0 ORDER BY ip ");

while($data = $db->FetchArray()) 
{

?>


<tr class="htt">
<td align="center"><?=$data["id"]; ?></td>

<td align="center"><?=$data["user"]; ?></td>

<td align="center"><?=$data["uip"]; ?></td>
<td align="center">


<form action="" method="post">

<input type="hidden" name="banned" value="<?=$data["id"]; ?>" />

<input type="submit" value="��������" />

</form>


<td align="center">

<form action="" method="post">

<input type="hidden" name="banneds" value="<?=$data["id"]; ?>" />

<input type="submit" value="�������� ���� IP" />

</form>

</td>


<td align="center">

<form action="" method="post">

<input type="hidden" name="hide" value="<?=$data["id"]; ?>" />
<input type="submit" value="������" />

</form>

</td>

</tr>


<?php

}

?>


</table>

</div>
<div class="fon-bottom"></div>				
</div>
<br><br>
</div>            